using System;
using System.Threading;

namespace BasicThread
{
    public class MyThreadClass
    {
        // The form sets this so thread output goes to the TextBox instead of the console.
        public static Action<string> Output;

        public static void Thread1()
        {
            // Loop terminates in the fifth attempt (LoopCount 0..5)
            for (int LoopCount = 0; LoopCount <= 5; LoopCount++)
            {
                Thread thread = Thread.CurrentThread;
                Output?.Invoke("Name of Thread: " + thread.Name + " Process = " + LoopCount);

                // Suspend the current thread for 1.5 seconds
                Thread.Sleep(1500);
            }
        }
    }
}
