using System;
using System.Threading;
using System.Windows.Forms;

namespace BasicThread
{
    public partial class FrmBasicThread : Form
    {
        public FrmBasicThread()
        {
            InitializeComponent();
            // Route thread output to the TextBox (instead of the console)
            MyThreadClass.Output = AppendOutput;
        }

        // Thread-safe write to the TextBox
        private void AppendOutput(string text)
        {
            if (txtOutput.InvokeRequired)
            {
                txtOutput.BeginInvoke(new Action<string>(AppendOutput), text);
                return;
            }
            txtOutput.AppendText(text + Environment.NewLine);
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            btnRun.Enabled = false;
            txtOutput.Clear();
            lblStatus.Text = "-Before starting thread-";
            AppendOutput("-Before starting thread-");

            // Create two (2) threads named Thread A and Thread B
            Thread ThreadA = new Thread(new ThreadStart(MyThreadClass.Thread1));
            ThreadA.Name = "Thread A";
            Thread ThreadB = new Thread(new ThreadStart(MyThreadClass.Thread1));
            ThreadB.Name = "Thread B";

            // A helper thread starts A and B, then uses Join() to wait for them,
            // so the form stays responsive while the threads run.
            Thread coordinator = new Thread(() =>
            {
                ThreadA.Start();
                ThreadB.Start();

                // Join() blocks the calling thread until the thread terminates
                ThreadA.Join();
                AppendOutput("The thread 0x" + ThreadA.ManagedThreadId.ToString("x") + " has exited with code 0 (0x0).");
                ThreadB.Join();
                AppendOutput("The thread 0x" + ThreadB.ManagedThreadId.ToString("x") + " has exited with code 0 (0x0).");
                AppendOutput("-End of Thread-");

                // Update the label once the threads have stopped
                this.BeginInvoke(new Action(() =>
                {
                    lblStatus.Text = "-End of Thread-";
                    btnRun.Enabled = true;
                }));
            });
            coordinator.IsBackground = true;
            coordinator.Start();
        }
    }
}
